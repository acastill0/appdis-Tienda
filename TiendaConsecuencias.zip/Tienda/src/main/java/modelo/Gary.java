package modelo;

public class Gary {

}
