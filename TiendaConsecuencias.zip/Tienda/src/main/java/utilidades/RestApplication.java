package utilidades;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/srv")
public class RestApplication extends Application{

}
