package on;

import java.util.List;

import dao.CategoriaDAO;
import dao.PeliculaDAO;
import dao.UsuarioDAO;
import modelo.Usuario;

public class GestionTiendaON {

	UsuarioDAO ud = new UsuarioDAO();
	CategoriaDAO cd = new CategoriaDAO();
	PeliculaDAO pd = new PeliculaDAO();

	public void crearUsu(Usuario u) {
		ud.insertar(u);
	}

	public Usuario buscarUsu(String cedula) {
		return ud.buscar(cedula);
	}

	public boolean actulizarUsu(Usuario u) {
		boolean aux = false;
		Usuario ub = buscarUsu(u.getCedula());
		if (ub.getCedula() != (null)) {
			ud.actualizar(u);
			aux = true;
		}
		return aux;
	}

	public boolean eliminarUsu(String cedula) {
		boolean aux = false;
		Usuario u = buscarUsu(cedula);
		if (u.getCedula() != (null)) {
			ud.borrar(cedula);
			aux = true;
		}
		return aux;
	}

	public List<Usuario> listadoUsus() {
		return ud.listadoUsuarios();
	}

	public List<Usuario> listadoUsuBuscado(String cedula) {
		return ud.listadoUsuarioBuscado(cedula);
	}

	public boolean logueado(String correo, String contraseña) {
		boolean aux = false;
		Usuario ul = ud.logueadoUsu(correo);
		System.out.println("<<<<>>>> UL "+ul);
//		if (ul.getCedula() != (null)) {
//			if ((ul.getCorreo() == correo) && (ul.getPassword() == contraseña)) {
//				aux = true;
//			}
//		}

		return aux;
	}
}
