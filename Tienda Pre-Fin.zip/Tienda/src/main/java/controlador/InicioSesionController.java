package controlador;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import dao.UsuarioDAO;
import modelo.Usuario;

/*
 * Clase que se crea para el mantenimiento del inicio de sesión en la WEB
 * @author: Lucy Garay, Adriana Castillo
 * */
@ManagedBean
@SessionScoped
@ViewScoped

public class InicioSesionController {
	@Inject
	private UsuarioDAO ud;

	private String correo;
	private String pass;

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String login() {

		Usuario usuAd = ud.logueadoAdmin(correo, pass);
		if (usuAd != null) {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().getSessionMap().put("user", correo);
			limpiar();
			return "main";
		} else {
			FacesMessage fmss = new FacesMessage("Error", "Error de inicio de sesión");
			FacesContext.getCurrentInstance().addMessage(null, fmss);
			limpiar();
			return null;
		}
	}

	public String logout() {
		FacesContext context = FacesContext.getCurrentInstance();
		context.getExternalContext().invalidateSession();
		return "login";
	}

	/**
	 * Método encargado de iniciar la sesión de un usuario.
	 * 
	 * @return String: La página a redireccionar al usuario cuando se termine el
	 *         inicio de sesión.
	 */
	public String iniciarSesion() {

		Sesion.iniciarSesion(FacesContext.getCurrentInstance());
		Sesion.setDatosSesion("nomUsuario", "Administrador");

		return "main?faces-redirect=true";
	}

	/**
	 * Método encargado de cerrar la sesión de usuario.
	 * 
	 * @return String: La página a redireccionar al usuario cuando se cierre la
	 *         sesión.
	 */
	public String cerrarSesion() {
		System.out.println("---------------> Cierra");
		try {
			Sesion.iniciarSesion(FacesContext.getCurrentInstance());
			Sesion.cerrarSesion();

			return "index?faces-redirect=true";
		} catch (Exception e) {
			e.printStackTrace();

			return null;
		}
	}

	public void limpiar() {
		correo = "";
		pass = "";
	}

}
