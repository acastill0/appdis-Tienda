package modelo;
/*
 * Clase que se setearan los datos de la pelicura para consumo del cliente movil
 * @author: Lucy Garay, Adriana Castillo
 * */
public class DetalleCarrito {

	private int id;
	private int cantidad;
	private double precio;

	private int pelicula_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getPelicula_id() {
		return pelicula_id;
	}

	public void setPelicula_id(int pelicula_id) {
		this.pelicula_id = pelicula_id;
	}

	@Override
	public String toString() {
		return "DetalleCarrito [id=" + id + ", cantidad=" + cantidad + ", precio=" + precio + ", pelicula_id="
				+ pelicula_id + "]";
	}

}
