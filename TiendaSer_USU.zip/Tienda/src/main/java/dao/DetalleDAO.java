package dao;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import modelo.Detalle;
import modelo.Pelicula;

public class DetalleDAO {
	@Inject
	private EntityManager entityManager;


		
	
}
